$( window ).on( "load", function() {
        $(".mycar").carousel();
        $(".crsl").carousel('pause');
        $('.fst').addClass('color2')
});
function changeslide(e) {
  $('.mySlider').slick('slickGoTo', e);
}

$( document).ready(function() {
    $(".crsl").carousel('pause');
    $(".crsl").on("mouseenter",function() {
    $(this).carousel('cycle');
    }).on("mouseleave", function() {
      $(this).carousel('pause');
  });
  $(".secondSlide").click(function(){
    $(".mycar").carousel("1");
  });
  $(".btnNext").click(function () {
    $(".mycar").carousel("next");
    console.log('dfdafd');
  });
  $('.mySlider').slick({
    prevArrow: $('.myprevbtn'),
    nextArrow:  $('.mynextbtn'),
    adaptiveHeight: true,
    swipe:false,
  });
  $('.mySlider').on('beforeChange', function(event, slick, currentSlide, nextSlide){
      $('.m0').removeClass('color2');
      if (nextSlide==0){ $('.fst').addClass('color2');}
      if (nextSlide==1){ $('.scd').addClass('color2');}
      if (nextSlide==2){ $('.thd').addClass('color2');}
  });
});





