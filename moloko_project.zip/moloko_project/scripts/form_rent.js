var clientCount = 0;
var trunb, name, surname, phone_number, email_adress, pay_way, agree_status;
var time_start, time_end
function photo_tarif(e) {
  $('.rate').css('color','black')
  $('.rate').text(e)
}
function agreement() {
  let trunb2 = $('.agree_checkbox')
  agree_status = trunb2[0].checked;
  if (agree_status){
    $('.agr').removeClass('voskl');
  }
  console.log(agree_status);
}

function rem(el1,el2) {
  $(el2).css('border','#D3A490 2px solid')
  $(el2).removeClass('empty');
  $(el1).removeClass('voskl');
}
function addStudia(e) {
  $('.addService').text('\n');
  if (e==2){
    trunb = $('.studia_checkbox')
  }else{
    trunb = $('.hall_checkbox')
  }
  for (i = 0; i < trunb.length; i++) {
    if (trunb[i].checked) {
      console.log(trunb[i].labels[0].innerText)
      $('.addService').text($('.addService').text()+'\n'+trunb[i].labels[0].innerText)
    }
  }
}




$( document).ready(function() {
    
  $(".btnrent2").click(function(){
      $('.btnrent1').addClass('btn2');
      $('.btnrent1').removeClass('btn1');
      $('.btnrent2').removeClass('btn2');
      $('.btnrent2').addClass('btn1');
      $('.additions').css('display', 'block');
      $('.addition_text').css('display', 'block');
      $('.rent1').css('display', 'none');
      $('.rent2').css('display', 'block');
      $('.rent1 input:checkbox').prop('checked', false);
      $('.rate').css('color','black')
      $('.rate').text('Аренда студии под мероприятия');
    });
    $(".btnrent1").click(function(){
      $('.btnrent2').addClass('btn2');
      $('.btnrent2').removeClass('btn1');
      $('.btnrent1').removeClass('btn2');
      $('.btnrent1').addClass('btn1');
      $('.additions').css('display', 'block');
      $('.addition_text').css('display', 'block');
      $('.rent2').css('display', 'none');
      $('.rent1').css('display', 'block');
      $('.rent2 input:checkbox').prop('checked', false);
      $('.rate').css('color','black')
      $('.rate').text('Аренда съемочного зала');
    });
    $(".btnphoto").click(function(){
      $('.btnrent').addClass('btn2');
      $('.btnrent').removeClass('btn1');
      $('.btnphoto').removeClass('btn2');
      $('.btnphoto').addClass('btn1');
      $('.additions').css('display', 'block');
      $('.addition_text').css('display', 'none');
      $('.photoses').css('display', 'block');
      $('.rent2').css('display', 'none');
      $('.rent1').css('display', 'none');
      $('.rentBtns').css('display', 'none');
      $('.addSpace').css('display', 'block');
      $('.service').css('color','black')
      $('.service').text('Фотоссесия');
    });
    $(".btnrent").click(function(){
      $('.btnphoto').addClass('btn2')
      $('.btnphoto').removeClass('btn1')
      $('.btnrent').removeClass('btn2')
      $('.btnrent').addClass('btn1')
      $('.rentBtns').css('display', 'block')
      $('.photoses').css('display', 'none');
      $('.additions').css('display', 'none');
      $('.service').css('color','black')
      $('.service').text('Аренда');
    });
    $(".plus").click(function(){
      if (parseInt($('.addClient').val())<5){
        clientCount = parseInt($('.addClient').val())+1;
        $('.addClient').val(clientCount);
      }
    });
    $(".minus").click(function(){
      if (parseInt($('.addClient').val())>0){
        clientCount = parseInt($('.addClient').val())-1;
        $('.addClient').val(clientCount);
      }
    });
    $(".cardpay").click(function(){
      $('.cardpay').css('border','#D3A490 2px solid');
      $('.cashpay').css('border','#D3A490 2px solid');
      $('.cardpay').removeClass('voskl');
      $('.cashpay').removeClass('voskl');
      $('.cashpay').addClass('btn2')
      $('.cashpay').removeClass('btn1')
      $('.cardpay').removeClass('btn2')
      $('.cardpay').addClass('btn1')
      pay_way = 'card'
    });
    $(".cashpay").click(function(){
      $('.cashpay').css('border','#D3A490 2px solid');
      $('.cardpay').css('border','#D3A490 2px solid');
      $('.cardpay').removeClass('voskl');
      $('.cashpay').removeClass('voskl');
      $('.cardpay').addClass('btn2')
      $('.cardpay').removeClass('btn1')
      $('.cashpay').removeClass('btn2')
      $('.cashpay').addClass('btn1')
      pay_way = 'cash'
    });
    $(".correct").click(function(){
      $('.correct').css('border','#D3A490 2px solid');
      $('.correct').removeClass('btn2')
      $('.correct').addClass('btn1')
      $('.correct').removeClass('voskl');
      pay_way = 'card'
    });
    

    $(".rent_btn").click(function(){
      let flag = true;
      if ($('.service').text()=='' || $('.service').text()=='Не заполнено'){
        $('.service').text('Не заполнено'); 
        $('.service').css('color','#86573C');
        flag=false;
      }
      if ($('.rate').text()=='' || $('.rate').text()=='Не заполнено'){
        $('.rate').text('Не заполнено'); 
        $('.rate').css('color','#86573C');
        flag=false;
      }
      if ($('.time').text()=='' || $('.time').text()=='Не заполнено' || $('.time').text()=='Некорректная дата'){
        $('.time').text('Не заполнено'); 
        $('.time').css('color','#86573C');
        flag=false;
      }
      if ($('.cardpay').hasClass('btn2') && $('.cashpay').hasClass('btn2')){
        $('.cardpay').css('border','#86573C 2px solid');
        $('.cashpay').css('border','#86573C 2px solid');
        $('.cardpay').addClass('voskl');
        $('.cashpay').addClass('voskl');
        flag=false;
      }
      if ($('.correct').hasClass('btn2')){
        $('.correct').css('border','#86573C 2px solid');
        $('.correct').addClass('voskl');
        flag=false;
      }
      if ($('#fname').val()==''){
        $('#fname').css('border','#86573C 2px solid')
        $('.fn').addClass('voskl');
        flag=false;
      }
      if ($('#sname').val()==''){
        $('#sname').css('border','#86573C 2px solid')
        flag=false;
        $('.sn').addClass('voskl');
      }
      if ($('#phone').val()==''){
        $('#phone').css('border','#86573C 2px solid')
        flag=false;
        $('.ph').addClass('voskl');
      }
      if ($('#email').val()==''){
        $('#email').css('border','#86573C 2px solid')
        flag=false;
        $('.em').addClass('voskl');
      }
      if (!agree_status){
        $('.agr').addClass('voskl');
        flag=false;
      }

      if (flag==true){
         $('.popup_window').css('display', 'block');
      setTimeout(function(){$('.popup_window').css('display','none')},5000);
      }

     
    });


    var calendarEl = document.getElementById('calendar');

    var calendar = new FullCalendar.Calendar(calendarEl, {
        plugins: ['timeGrid','dayGrid', 'interaction', 'timeGrid'],
        defaultView: 'timeGridSevebDay',
        views: {
            timeGridSevebDay: {
              type: 'timeGrid',
              duration: { days: 7 }
            }
          },
        header: {
            left: 'prev today next',
            center:'title',
            right:'',
        },
        slotLabelFormat: [
            { month: 'long', year: 'numeric' }, // top level of text
            { weekday: 'short' }, // lower level of text
            {
                hour: '2-digit',
                minute: '2-digit',
                omitZeroMinute: false
              }
        ],
        slotDuration: '01:00',
        selectable: true,
        selectMirror: true,
        unselectAuto:'',
        selectOverlap:false,
        allDaySlot: false,
        locale:'ru',
        minTime: "09:00",
        maxTime: "22:00",
        height:'auto',
        select: function(info) {
          time_start = info.startStr;
          time_end = info.endStr;
          console.log(info.startStr);
          
          if ((info.startStr.substring(8,10)+'.'
          +info.startStr.substring(5,7)+'.'
          +info.startStr.substring(0,4)+' '
          +$('.fc-time:last-child').text()).length < 25){
            $('.time').css('color','black');
            $('.time').text(info.startStr.substring(8,10)+'.'
                                +info.startStr.substring(5,7)+'.'
                                +info.startStr.substring(0,4)+' '
                                +$('.fc-time:last-child').text());
          }else{
            $('.time').css('color','#86573C');
            $('.time').text('Некорректная дата');
          }
        }
        }); 
  
      calendar.render();
      // var str = "<p style=\"margin:0; height:50px; display: flex; flex-direction:row; justify-content:space-around; align-items:center\">Свободно</p><p style=\"margin:0; height:50px; display: flex; flex-direction:row; justify-content:space-around; align-items:center\">Свободно</p><p style=\"margin:0; height:50px; display: flex; flex-direction:row; justify-content:space-around; align-items:center\">Свободно</p><p style=\"margin:0; height:50px; display: flex; flex-direction:row; justify-content:space-around; align-items:center\">Свободно</p><p style=\"margin:0; height:50px; display: flex; flex-direction:row; justify-content:space-around; align-items:center\">Свободно</p><p style=\"margin:0; height:50px; display: flex; flex-direction:row; justify-content:space-around; align-items:center\">Свободно</p><p style=\"margin:0; height:50px; display: flex; flex-direction:row; justify-content:space-around; align-items:center\">Свободно</p><p style=\"margin:0; height:50px; display: flex; flex-direction:row; justify-content:space-around; align-items:center\">Свободно</p><p style=\"margin:0; height:50px; display: flex; flex-direction:row; justify-content:space-around; align-items:center\">Свободно</p><p style=\"margin:0; height:50px; display: flex; flex-direction:row; justify-content:space-around; align-items:center\">Свободно</p><p style=\"margin:0; height:50px; display: flex; flex-direction:row; justify-content:space-around; align-items:center\">Свободно</p><p style=\"margin:0; height:50px; display: flex; flex-direction:row; justify-content:space-around; align-items:center\">Свободно</p><p style=\"margin:0; height:50px; display: flex; flex-direction:row; justify-content:space-around; align-items:center\">Свободно</p>";
      // $(".fc-day").html(str);
      $(".time").click(function () {
          console.log($('.fc-time:last-child').text())
        $('#showTIME').text($('.fc-time:last-child').text());
      });

});